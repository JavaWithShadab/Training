package pack;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Login
 */
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		try
		{
			
			Connection conn=Dbconnection.getConnection();
			String uname=req.getParameter("user");
			String password=req.getParameter("pass");
			req.setAttribute("user", uname);
			PreparedStatement ps=conn.prepareStatement("select * from rahman3 where username=? and password=?");
			ps.setString(1, uname);
			ps.setString(2, password);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				req.getRequestDispatcher("website.jsp").forward(req, res);
				
			}
			else
			{
				res.sendRedirect("error1.jsp");
			}
			
		}
	
		catch(Exception e)
		{
			e.printStackTrace();
		}

}
}