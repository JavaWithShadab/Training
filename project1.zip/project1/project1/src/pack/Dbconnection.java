package pack;
import java.sql.*;

public class Dbconnection {
	private static Connection conn;
	static 
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","rahman");
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}	
	public static Connection getConnection()
	{
		return conn;
	}

}
