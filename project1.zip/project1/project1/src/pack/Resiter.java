package pack;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
/**
 * Servlet implementation class Resiter
 */
public class Resiter extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
	try
	{
		Connection conn=Dbconnection.getConnection();
	
		String UserName=req.getParameter("user1");
		String Address=req.getParameter("add");
		String Email=req.getParameter("email");
		String Password=req.getParameter("pass");
		String checkbox=req.getParameter("box");
		String gender=req.getParameter("radios");
		req.setAttribute("user",UserName);
		PreparedStatement ps=conn.prepareStatement("insert into rahman3 values(?,?,?,?,?,?)");
		ps.setString(1, UserName);
		ps.setString(2, Address);
		ps.setString(3, Email);
		ps.setString(4, Password);
		ps.setString(5, checkbox);
		ps.setString(6, gender);
		int i=ps.executeUpdate();
		if(i>0)
		{
			req.getRequestDispatcher("welcome.jsp").forward(req, res);
		}
		else
		{
			res.sendRedirect("error.jsp");
		}
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	}

}
